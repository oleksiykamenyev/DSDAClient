DSDA Command Line Client
========================

This is a command line application to extract info from DSDA through command line.
